''' Configuration file '''

class Database:
    DB = 'the'
    HOST = '127.0.0.1'
    PORT = 3306
    USER = 'root'
    PAS  = ''

class App:
    API_VERSION = 1
    URL_PREFIX = '/api/v' + str(API_VERSION)
    DEBUG = True
    HOST = '127.0.0.1'
    PORT = 8000
    SECRET = 'Y@QRAduv&YQVeX^#zieEu&qwa$sDtUR7%KVOu2Wyp9!fOgZ!I/YjX@W?$4W*V/Qd96*'
